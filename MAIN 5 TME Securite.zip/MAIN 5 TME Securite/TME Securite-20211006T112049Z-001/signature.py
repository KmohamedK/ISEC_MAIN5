import base64 
import subprocess
from hashlib import sha256, md5
import binascii
from itertools import combinations
from decimal import Decimal
from itertools import combinations
import numpy as np
import numpy.linalg as la
import numpy.linalg as alg
from numpy.linalg.linalg import solve
import scipy
from sympy import integer_nthroot
import math
import fpylll

def signatures(document, secret_key):
    # prépare les arguments à envoyer à openssl
    args = ['openssl', 'dgst', '-sha256', '-sign', secret_key]
    
    # si le message clair est une chaine unicode, on est obligé de
    # l'encoder en bytes() pour pouvoir l'envoyer dans le pipeline vers 
    # openssl
    if isinstance(document, str):
        document = document.encode('utf-8')
    
    # ouvre le pipeline vers openssl. envoie plaintext sur le stdin de openssl, récupère stdout et stderr
    #    affiche la commande invoquée
    #    print('debug : {0}'.format(' '.join(args)))
    result = subprocess.run(args, input=document, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # si un message d'erreur est présent sur stderr, on arrête tout
    # attention, sur stderr on récupère des bytes(), donc on convertit
    error_message = result.stderr.decode()
    # if error_message != '':
    #     raise OpensslError(error_message)

    # OK, openssl a envoyé le chiffré sur stdout, en base64.
    # On récupère des bytes, donc on en fait une chaine unicode
    return base64.b16encode(result.stdout).decode()


document = "twink riled arise derby peats"
signa = signatures(document, "my.key.pem")

print(signa)