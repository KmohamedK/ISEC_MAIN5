#include <iostream>
#include <map>
#include <gmpxx.h>
#include <omp.h>
using namespace std; 

int main(){

    mpz_class N, c, e, k1, max_k, tmp;
    map<mpz_class, mpz_class> A; 
    N = "0x1ea982ba8f01d5e03163b0409a554484b8e145af768a8d3e66b84c9723d8604a33bd7c52033def81adfaf49beaa4f0f2b3b92370efb88f07665c5c35afdfd94752eacc4cf24ff3b96954ff391abaf39108df0cf11c26567ac2aa408143038ed11d53172667b95637a7cd3d6bc8972e6a4d7a503730db2af935d3baf8d5a5465d";
    c = "0x03afb74fe16b63b117908132705a5c19be3baf764258fa5772fe955677b69b996dcacf0ca785ac7d652ed4bbaa8a9e2c552050b3780125d67b033b011754f5891694c4435f0a3a6b9e233fbf5af448275d152bfbb1f82f0b7b9d85bbb1e1b07319cd8eef7e2d42a2daca67eabda506ee9a77481d73e6ccf8cef790ed2e6f479a";
    e = "-0x10001"; 
    k1 = 1; 
    max_k = 2; 
    tmp = 1; 
    mpz_pow_ui(max_k.get_mpz_t(), max_k.get_mpz_t(), 24);
    while(k1 < max_k) {
        mpz_powm(tmp.get_mpz_t(), k1.get_mpz_t(), e.get_mpz_t(), N.get_mpz_t()); 
         A[(c * tmp) % N] = k1; 
         k1 += 1;
    }
    cout << "Dico généré" << endl; 
    e = -e;

    #pragma omp parallel 
    {
        mpz_class e1 (e); 
        mpz_class N1 (N); 
        mpz_class max (max_k) ; 
        mpz_class temp; 
        mpz_class k2; 
        for(k2 = omp_get_thread_num() + 1; k2 < max; k2+=omp_get_num_threads()) {
            mpz_powm(temp.get_mpz_t(), k2.get_mpz_t(), e1.get_mpz_t(), N1.get_mpz_t()); 
            auto it = A.find(temp);
            if (it != A.end()) {
                mpz_class K;
                K = it->second * k2; 
                cout << "K = " << K << endl; 
                break; 
            }
        }
    }
    return 0;
}

