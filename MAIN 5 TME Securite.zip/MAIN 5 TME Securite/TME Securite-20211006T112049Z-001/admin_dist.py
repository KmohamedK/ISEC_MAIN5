import base64 
import subprocess
from hashlib import sha256, md5
import binascii
from itertools import combinations
from decimal import Decimal
from itertools import combinations
import numpy as np
import numpy.linalg as la
import numpy.linalg as alg
from numpy.linalg.linalg import solve
import scipy
from sympy import integer_nthroot
import math
import fpylll


def brent(f, x0):
    # main phase: search successive powers of two
    power = lam = 1
    tortoise = x0
    hare = f(x0)  # f(x0) is the element/node next to x0.
    while tortoise != hare:
        if power == lam:  # time to start a new power of two?
            tortoise = hare
            power *= 2
            lam = 0
        hare = f(hare)
        lam += 1
    print("hello\n ")
    # Find the position of the first repetition of length λ
    tortoise = hare = x0
    for i in range(lam):
    # range(lam) produces a list with the values 0, 1, ... , lam-1
        hare = f(hare)
    # The distance between the hare and tortoise is now λ.

    # Next, the hare and tortoise move at same speed until they agree
    mu = 0
    while tortoise != hare:
        tortoise = f(tortoise)
        hare = f(hare)
        mu += 1
    print("salut \n")
    return lam, mu

operateur = "Ryann"

def f(x):
    return sha256((operateur + x).encode()).hexdigest()[:14]
def f_mu_times(f, x, mu):
    for i in range(mu):
        x = f(x)
    return x
x0 = "0"
lam, mu = brent(f, x0)
x1 = f_mu_times(f, x0, mu - 1)
x2 = f_mu_times(f, x0, mu - 1 + lam)
assert sha256((operateur+x1).encode()).hexdigest()[:14] == sha256((operateur+x2).encode()).hexdigest()[:14]
print(base64.b16encode((operateur+x1).encode()).decode())
print(base64.b16encode((operateur+x2).encode()).decode())